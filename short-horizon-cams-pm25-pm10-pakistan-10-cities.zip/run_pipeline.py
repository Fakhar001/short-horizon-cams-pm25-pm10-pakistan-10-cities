#!/usr/bin/env python3
"""Run the manuscript-matched PM2.5/PM10 forecasting analysis."""

from __future__ import annotations

import argparse
from pathlib import Path

from pm25pm10_q1.config import load_config
from pm25pm10_q1.pipeline import run_pipeline


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Reproduce the PM2.5/PM10 Q1 benchmark, SARIMA, inference, and SHAP analyses."
    )
    parser.add_argument("--config", type=Path, default=Path("study_config.yaml"))
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    parser.add_argument("--output-dir", type=Path, default=Path("results"))
    parser.add_argument("--cities", nargs="*", help="Optional subset of configured city names.")
    parser.add_argument(
        "--sarima-protocol",
        choices=("fixed_origin_training_only", "rolling_one_step"),
        help="Override the SARIMA protocol in the YAML file.",
    )
    parser.add_argument(
        "--sarima-backend",
        choices=("statsmodels", "css"),
        help="Use state-space SARIMA or the dependency-light conditional least-squares fallback.",
    )
    parser.add_argument("--skip-sarima", action="store_true")
    parser.add_argument("--skip-mlp", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = load_config(args.config)
    if args.sarima_protocol:
        config["sarima"]["protocol"] = args.sarima_protocol
    if args.sarima_backend:
        config["sarima"]["backend"] = args.sarima_backend
    run_pipeline(
        config=config,
        data_dir=args.data_dir,
        output_dir=args.output_dir,
        selected_cities=args.cities,
        skip_sarima=args.skip_sarima,
        skip_mlp=args.skip_mlp,
    )


if __name__ == "__main__":
    main()

