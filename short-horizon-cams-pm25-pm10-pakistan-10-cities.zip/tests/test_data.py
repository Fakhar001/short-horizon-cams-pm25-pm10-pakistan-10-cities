from __future__ import annotations

import unittest

import numpy as np
import pandas as pd

from pm25pm10_q1.data import ALL_FEATURES, prepare_city


def synthetic_frame(n: int = 2184) -> pd.DataFrame:
    index = np.arange(n, dtype=float)
    return pd.DataFrame(
        {
            "city": "Test City",
            "timestamp": pd.date_range("2025-01-01", periods=n, freq="h", tz="UTC"),
            "pm2_5": 20.0 + 0.01 * index,
            "pm10": 30.0 + 0.02 * index,
            "temperature_2m": 15.0 + np.sin(index / 24.0),
            "relative_humidity_2m": 50.0 + np.cos(index / 24.0),
            "wind_speed_10m": 5.0 + 0.1 * np.sin(index / 8.0),
            "wind_direction_10m": np.mod(index * 7.0, 360.0),
            "surface_pressure": 1000.0 + 0.2 * np.cos(index / 48.0),
            "precipitation": np.zeros(n),
        }
    )


class DataProtocolTests(unittest.TestCase):
    def test_exact_split_and_window_counts(self):
        prepared = prepare_city(synthetic_frame())
        self.assertEqual(prepared.slices["train"].stop, 1528)
        self.assertEqual(prepared.slices["validation"].stop - prepared.slices["validation"].start, 218)
        self.assertEqual(prepared.slices["test"].stop - prepared.slices["test"].start, 438)
        self.assertEqual(len(prepared.blocks["train"].y), 1504)
        self.assertEqual(len(prepared.blocks["validation"].y), 194)
        self.assertEqual(len(prepared.blocks["test"].y), 414)

    def test_scaler_uses_training_rows_only(self):
        frame = synthetic_frame()
        prepared = prepare_city(frame)
        encoded = prepared.frame.loc[:, ALL_FEATURES].astype(float).to_numpy()
        expected = encoded[:1528].mean(axis=0)
        np.testing.assert_allclose(prepared.scaler.mean_, expected, rtol=0, atol=1e-12)
        self.assertFalse(np.allclose(prepared.scaler.mean_, encoded.mean(axis=0)))

    def test_test_windows_do_not_cross_block_boundary(self):
        prepared = prepare_city(synthetic_frame())
        first_test_origin = prepared.blocks["test"].raw_indices[0]
        self.assertEqual(first_test_origin, prepared.slices["test"].start + 24)


if __name__ == "__main__":
    unittest.main()

