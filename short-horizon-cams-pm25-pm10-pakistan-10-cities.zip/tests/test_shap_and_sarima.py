from __future__ import annotations

import unittest

import numpy as np
from sklearn.linear_model import Ridge

from pm25pm10_q1.classical import ConditionalLeastSquaresSarima
from pm25pm10_q1.shap_linear import exact_linear_shap


class ShapAndSarimaTests(unittest.TestCase):
    def test_exact_linear_shap_reconstructs_multioutput_prediction(self):
        rng = np.random.default_rng(11)
        train_X = rng.normal(size=(100, 18))
        train_y = rng.normal(size=(100, 2))
        test_X = rng.normal(size=(20, 18))
        model = Ridge(alpha=1.0).fit(train_X, train_y)
        result = exact_linear_shap(
            model,
            train_X,
            test_X,
            feature_names=("pm2_5", "pm10", "temperature_2m"),
            target_names=("pm2_5", "pm10"),
            lookback=6,
        )
        self.assertLess(result.max_reconstruction_error, 1e-8)
        self.assertEqual(len(result.group_summary), 6)
        shares = result.group_summary.groupby("target")["share"].sum().to_numpy()
        np.testing.assert_allclose(shares, np.ones(2), atol=1e-12)

    def test_css_sarima_forecast_is_finite(self):
        index = np.arange(300)
        series = 50.0 + 0.1 * index + 3.0 * np.sin(2.0 * np.pi * index / 24.0)
        model = ConditionalLeastSquaresSarima(24).fit(series[:250])
        prediction = model.forecast(series[:250], 20)
        self.assertEqual(prediction.shape, (20,))
        self.assertTrue(np.isfinite(prediction).all())


if __name__ == "__main__":
    unittest.main()

