from __future__ import annotations

import unittest

import numpy as np
import pandas as pd

from pm25pm10_q1.inference import dm_hac_test, paired_city_bootstrap


class InferenceTests(unittest.TestCase):
    def test_bootstrap_preserves_pairing_and_sign(self):
        rows = []
        for city_index in range(10):
            for target in ("pm2_5", "pm10"):
                rows.extend(
                    [
                        {"city": f"C{city_index}", "target": target, "model": "Ridge-AR", "RMSE": 5.0 + city_index / 10},
                        {"city": f"C{city_index}", "target": target, "model": "SARIMA", "RMSE": 20.0 + city_index / 10},
                    ]
                )
        result = paired_city_bootstrap(pd.DataFrame(rows), replicates=2000, seed=7)
        self.assertTrue(result["interval_entirely_below_zero"].all())
        self.assertTrue((result["ci_upper"] < 0).all())

    def test_dm_hac_direction(self):
        differential = -10.0 + np.sin(np.arange(414) / 10.0)
        result = dm_hac_test(differential, hac_lag=24)
        self.assertLess(result["statistic"], 0)
        self.assertLess(result["p_value_two_sided"], 0.05)


if __name__ == "__main__":
    unittest.main()

