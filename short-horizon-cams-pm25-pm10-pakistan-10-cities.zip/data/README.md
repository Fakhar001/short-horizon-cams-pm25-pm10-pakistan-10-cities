# Included study data

The CSV files contain hourly CAMS-derived PM2.5 and PM10 fields and aligned
meteorological predictors for ten Pakistani cities from 6 November 2025 through
4 February 2026 (UTC). There are 2,184 rows per city and 21,840 rows in the
combined file.

The particulate-matter variables were obtained through the Open-Meteo Air
Quality API and represent gridded model-derived estimates. They must not be
described as direct ground-station observations. Meteorological predictors were
obtained from the Open-Meteo historical archive.

`analysis_manifest.json` records the original retrieval coordinates, study
period, row count, source description, lookback, split, and initial benchmark
model list.

