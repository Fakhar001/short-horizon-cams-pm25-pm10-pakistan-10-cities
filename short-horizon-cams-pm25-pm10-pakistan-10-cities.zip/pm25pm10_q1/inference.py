"""Paired city bootstrap and Diebold-Mariano-style forecast comparison."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import norm


def paired_city_bootstrap(
    city_metrics: pd.DataFrame,
    reference_model: str = "Ridge-AR",
    comparison_model: str = "Persistence",
    replicates: int = 10000,
    confidence_level: float = 0.95,
    seed: int = 20260731,
    excluded_cities: tuple[str, ...] = ("Rawalpindi",),
) -> pd.DataFrame:
    required = {"city", "model", "target", "RMSE"}
    if not required.issubset(city_metrics.columns):
        raise ValueError(f"City metrics require columns {sorted(required)}")
    rng = np.random.default_rng(int(seed))
    alpha = 1.0 - float(confidence_level)
    rows: list[dict[str, float | int | str | bool]] = []

    for target in sorted(city_metrics["target"].unique()):
        subset = city_metrics[city_metrics["target"] == target]
        pivot = subset.pivot(index="city", columns="model", values="RMSE").dropna(
            subset=[reference_model, comparison_model]
        )
        if excluded_cities:
            pivot = pivot.drop(index=list(excluded_cities), errors="ignore")
        differences = (pivot[reference_model] - pivot[comparison_model]).to_numpy(dtype=float)
        if len(differences) < 2:
            continue
        indices = rng.integers(0, len(differences), size=(int(replicates), len(differences)))
        bootstrap_means = differences[indices].mean(axis=1)
        lower, upper = np.quantile(bootstrap_means, [alpha / 2.0, 1.0 - alpha / 2.0])
        rows.append(
            {
                "target": target,
                "reference_model": reference_model,
                "comparison_model": comparison_model,
                "difference_definition": f"{reference_model} RMSE - {comparison_model} RMSE",
                "n_cities": int(len(differences)),
                "mean_difference": float(np.mean(differences)),
                "confidence_level": float(confidence_level),
                "ci_lower": float(lower),
                "ci_upper": float(upper),
                "replicates": int(replicates),
                "seed": int(seed),
                "interval_entirely_below_zero": bool(upper < 0),
            }
        )
    return pd.DataFrame(rows)


def dm_hac_test(loss_differential: np.ndarray, hac_lag: int = 24) -> dict[str, float | int]:
    differential = np.asarray(loss_differential, dtype=float)
    differential = differential[np.isfinite(differential)]
    n = len(differential)
    if n < 3:
        raise ValueError("At least three paired loss differences are required.")
    centered = differential - np.mean(differential)
    lag = min(int(hac_lag), n - 1)
    long_run_variance = float(np.dot(centered, centered) / n)
    for offset in range(1, lag + 1):
        covariance = float(np.dot(centered[offset:], centered[:-offset]) / n)
        weight = 1.0 - offset / (lag + 1.0)
        long_run_variance += 2.0 * weight * covariance
    long_run_variance = max(long_run_variance, np.finfo(float).eps)
    standard_error = float(np.sqrt(long_run_variance / n))
    statistic = float(np.mean(differential) / standard_error)
    p_value = float(2.0 * norm.sf(abs(statistic)))
    return {
        "n": int(n),
        "hac_lag": int(lag),
        "mean_loss_difference": float(np.mean(differential)),
        "hac_standard_error": standard_error,
        "statistic": statistic,
        "p_value_two_sided": p_value,
    }


def dm_results_from_predictions(
    predictions_long: pd.DataFrame,
    reference_model: str = "Ridge-AR",
    comparison_model: str = "SARIMA",
    hac_lag: int = 24,
) -> pd.DataFrame:
    required = {"city", "target", "timestamp", "model", "actual", "prediction"}
    if not required.issubset(predictions_long.columns):
        raise ValueError(f"Prediction table requires columns {sorted(required)}")
    selected = predictions_long[
        predictions_long["model"].isin([reference_model, comparison_model])
    ].copy()
    wide = selected.pivot_table(
        index=["city", "target", "timestamp"],
        columns="model",
        values=["actual", "prediction"],
        aggfunc="first",
    ).dropna()
    rows: list[dict[str, float | int | str]] = []

    for (city, target), group in wide.groupby(level=["city", "target"], sort=True):
        actual = group[("actual", reference_model)].to_numpy(dtype=float)
        ref_prediction = group[("prediction", reference_model)].to_numpy(dtype=float)
        cmp_prediction = group[("prediction", comparison_model)].to_numpy(dtype=float)
        differential = (actual - ref_prediction) ** 2 - (actual - cmp_prediction) ** 2
        rows.append(
            {
                "scope": "city",
                "city": city,
                "target": target,
                "difference_definition": f"{reference_model} squared error - {comparison_model} squared error",
                **dm_hac_test(differential, hac_lag),
            }
        )

    for target in sorted(selected["target"].unique()):
        target_wide = wide.xs(target, level="target")
        per_city_time: list[pd.DataFrame] = []
        for city, group in target_wide.groupby(level="city", sort=True):
            actual = group[("actual", reference_model)].to_numpy(dtype=float)
            ref_prediction = group[("prediction", reference_model)].to_numpy(dtype=float)
            cmp_prediction = group[("prediction", comparison_model)].to_numpy(dtype=float)
            timestamps = group.index.get_level_values("timestamp")
            per_city_time.append(
                pd.DataFrame(
                    {
                        "timestamp": timestamps,
                        "loss_difference": (actual - ref_prediction) ** 2
                        - (actual - cmp_prediction) ** 2,
                    }
                )
            )
        macro = pd.concat(per_city_time).groupby("timestamp")["loss_difference"].mean()
        rows.append(
            {
                "scope": "macro_city_mean_by_origin",
                "city": "ALL",
                "target": target,
                "difference_definition": f"{reference_model} squared error - {comparison_model} squared error",
                **dm_hac_test(macro.to_numpy(), hac_lag),
            }
        )
    return pd.DataFrame(rows)

