"""End-to-end orchestration and reproducibility outputs."""

from __future__ import annotations

import json
import hashlib
import importlib.metadata
import os
import platform
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from . import __version__
from .classical import sarima_forecast
from .data import load_city_csv, prepare_city
from .inference import dm_results_from_predictions, paired_city_bootstrap
from .metrics import metric_rows, peak_regime_rows
from .models import fit_benchmarks
from .shap_linear import exact_linear_shap


def _prediction_rows(
    city: str,
    model: str,
    target_names: tuple[str, ...],
    timestamps: np.ndarray,
    actual: np.ndarray,
    prediction: np.ndarray,
) -> pd.DataFrame:
    frames = []
    for target_index, target in enumerate(target_names):
        frames.append(
            pd.DataFrame(
                {
                    "city": city,
                    "target": target,
                    "timestamp": pd.to_datetime(timestamps, utc=True),
                    "test_origin": np.arange(len(timestamps), dtype=int),
                    "model": model,
                    "actual": actual[:, target_index],
                    "prediction": prediction[:, target_index],
                    "error": prediction[:, target_index] - actual[:, target_index],
                }
            )
        )
    return pd.concat(frames, ignore_index=True)


def _macro_metrics(city_metrics: pd.DataFrame) -> pd.DataFrame:
    return (
        city_metrics.groupby(["model", "target"], as_index=False)
        .agg(
            MAE_mean=("MAE", "mean"),
            MAE_sd=("MAE", "std"),
            RMSE_mean=("RMSE", "mean"),
            RMSE_sd=("RMSE", "std"),
            R2_mean=("R2", "mean"),
            R2_sd=("R2", "std"),
            Bias_mean=("Bias", "mean"),
            n_cities=("city", "nunique"),
        )
        .sort_values(["target", "RMSE_mean", "model"], kind="stable")
    )


def _data_quality(city: str, frame: pd.DataFrame) -> dict[str, float | int | str]:
    timestamps = pd.to_datetime(frame["timestamp"], utc=True)
    differences = timestamps.diff().dropna().dt.total_seconds().to_numpy()
    return {
        "city": city,
        "rows": int(len(frame)),
        "start": timestamps.min().isoformat(),
        "end": timestamps.max().isoformat(),
        "duplicate_timestamps": int(timestamps.duplicated().sum()),
        "non_hourly_gaps": int(np.sum(differences != 3600)),
        "missing_modelling_values": int(
            frame[
                [
                    "pm2_5",
                    "pm10",
                    "temperature_2m",
                    "relative_humidity_2m",
                    "wind_speed_10m",
                    "wind_direction_10m",
                    "surface_pressure",
                    "precipitation",
                ]
            ].isna().sum().sum()
        ),
        "pm2_5_mean": float(frame["pm2_5"].mean()),
        "pm10_mean": float(frame["pm10"].mean()),
        "pm2_5_p95": float(frame["pm2_5"].quantile(0.95)),
        "pm10_p95": float(frame["pm10"].quantile(0.95)),
    }


def _write_figures(
    output_dir: Path,
    macro_metrics: pd.DataFrame,
    shap_summary: pd.DataFrame,
    data_quality: pd.DataFrame,
) -> None:
    os.environ.setdefault("MPLCONFIGDIR", str(output_dir / ".matplotlib"))
    import matplotlib.pyplot as plt

    target_labels = {"pm2_5": "PM2.5", "pm10": "PM10"}

    # Figure 1: winter means with annual reference values shown as contextual
    # guides. These lines are not compliance tests for the 91-day means.
    if not data_quality.empty:
        ordered_cities = data_quality.sort_values("pm2_5_mean", ascending=False)["city"].tolist()
        figure, axes = plt.subplots(1, 2, figsize=(13.5, 5.2), sharey=False)
        standards = {
            "pm2_5": ((5.0, "WHO annual"), (15.0, "Pakistan NEQS annual")),
            "pm10": ((15.0, "WHO annual"), (120.0, "Pakistan NEQS annual")),
        }
        for axis, target in zip(axes, ("pm2_5", "pm10")):
            mean_column = f"{target}_mean"
            values = data_quality.set_index("city").loc[ordered_cities, mean_column]
            axis.bar(ordered_cities, values, color="#477DA8", width=0.72)
            axis.set_title(target_labels[target])
            axis.set_xticks(np.arange(len(ordered_cities)))
            axis.set_xticklabels(ordered_cities, rotation=55, ha="right")
            for color, (threshold, label) in zip(("#B23A48", "#2A9D8F"), standards[target]):
                axis.axhline(threshold, color=color, linestyle="--", linewidth=1.7,
                             label=f"{label}: {threshold:g} μg/m³")
            axis.grid(axis="y", alpha=0.22)
            axis.legend(loc="upper right", frameon=False, fontsize=8)
        axes[0].set_ylabel("Winter mean concentration (μg/m³)")
        figure.tight_layout()
        figure.savefig(output_dir / "figure1_city_means.png", dpi=300, bbox_inches="tight")
        plt.close(figure)

    # Figure 3: city macro-mean RMSE with ±1 across-city SD whiskers.
    figure, axes = plt.subplots(1, 2, figsize=(10.5, 5.2), sharex=True)
    plotted_maxima: list[float] = []
    for axis, target in zip(axes, ("pm2_5", "pm10")):
        subset = macro_metrics[macro_metrics["target"] == target].sort_values("RMSE_mean")
        y = np.arange(len(subset))
        axis.errorbar(
            subset["RMSE_mean"], y, xerr=subset["RMSE_sd"], fmt="o",
            color="#275D8C", ecolor="#6F879B", capsize=3, markersize=5,
        )
        axis.set_yticks(y)
        axis.set_yticklabels(subset["model"])
        if not subset.empty:
            plotted_maxima.extend((subset["RMSE_mean"] + subset["RMSE_sd"]).tolist())
        axis.grid(axis="x", alpha=0.22)
        axis.invert_yaxis()
    axes[0].set_xlabel("PM₂.₅ mean city RMSE (μg/m³)")
    axes[1].set_xlabel("PM₁₀ mean city RMSE (μg/m³)")
    if plotted_maxima:
        axes[0].set_xlim(left=0, right=max(plotted_maxima) * 1.12)
    figure.tight_layout()
    figure.savefig(output_dir / "figure3_macro_rmse.png", dpi=300, bbox_inches="tight")
    plt.close(figure)

    for target in sorted(macro_metrics["target"].unique()):
        subset = macro_metrics[macro_metrics["target"] == target].sort_values("RMSE_mean")
        figure, axis = plt.subplots(figsize=(9, 5.2))
        axis.barh(subset["model"], subset["RMSE_mean"], xerr=subset["RMSE_sd"], color="#2E6F95")
        axis.set_xlabel("Macro-averaged city RMSE (micrograms per cubic metre)")
        axis.set_title(f"{target_labels.get(target, target)} one-hour test RMSE")
        axis.grid(axis="x", alpha=0.25)
        figure.tight_layout()
        figure.savefig(output_dir / f"macro_rmse_{target}.png", dpi=300, bbox_inches="tight")
        plt.close(figure)

    if not shap_summary.empty:
        macro_shap = (
            shap_summary.groupby(["target", "feature"], as_index=False)["mean_abs_group_shap"]
            .mean()
        )
        macro_shap["share"] = macro_shap.groupby("target")["mean_abs_group_shap"].transform(
            lambda values: values / values.sum()
        )
        for target in sorted(macro_shap["target"].unique()):
            subset = macro_shap[macro_shap["target"] == target].sort_values("share")
            figure, axis = plt.subplots(figsize=(8.5, 5.2))
            axis.barh(subset["feature"], 100.0 * subset["share"], color="#D17A22")
            axis.set_xlabel("Share of grouped mean absolute exact linear SHAP (%)")
            axis.set_title(f"{target_labels.get(target, target)} Ridge-All attribution")
            axis.grid(axis="x", alpha=0.25)
            figure.tight_layout()
            figure.savefig(output_dir / f"shap_group_share_{target}.png", dpi=300, bbox_inches="tight")
            plt.close(figure)

        # Figure 5: contribution magnitudes in target concentration units, to
        # match the table. Predictor standardization does not standardize these
        # output-scale attributions.
        figure, axes = plt.subplots(1, 2, figsize=(13.5, 6.0), sharex=True)
        feature_order = [
            "pm2_5", "pm10", "surface_pressure", "temperature_2m",
            "relative_humidity_2m", "precipitation", "wind_speed_10m",
            "wind_dir_sin", "wind_dir_cos",
        ]
        feature_labels = {
            "pm2_5": "PM₂.₅ lags", "pm10": "PM₁₀ lags",
            "surface_pressure": "Surface pressure", "temperature_2m": "Temperature",
            "relative_humidity_2m": "Relative humidity", "precipitation": "Precipitation",
            "wind_speed_10m": "Wind speed", "wind_dir_sin": "Wind direction (sine)",
            "wind_dir_cos": "Wind direction (cosine)",
        }
        for axis, target in zip(axes, ("pm2_5", "pm10")):
            subset = macro_shap[macro_shap["target"] == target].copy()
            subset["order"] = subset["feature"].map({name: index for index, name in enumerate(feature_order)})
            subset = subset.sort_values("mean_abs_group_shap", ascending=True)
            y = np.arange(len(subset))
            axis.barh(y, subset["mean_abs_group_shap"], color="#477DA8")
            axis.set_yticks(y)
            axis.set_yticklabels([feature_labels.get(name, name) for name in subset["feature"]])
            axis.set_title(target_labels.get(target, target))
            axis.grid(axis="x", alpha=0.22)
        axes[0].set_xlabel("Mean absolute grouped attribution (μg/m³)")
        axes[1].set_xlabel("Mean absolute grouped attribution (μg/m³)")
        figure.tight_layout()
        figure.savefig(output_dir / "figure5_shap_attributions.png", dpi=300, bbox_inches="tight")
        plt.close(figure)


def run_pipeline(
    config: dict[str, Any],
    data_dir: Path,
    output_dir: Path,
    selected_cities: list[str] | None = None,
    skip_sarima: bool = False,
    skip_mlp: bool = False,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    configured_cities = dict(config["cities"])
    cities = selected_cities or list(configured_cities)
    unknown = sorted(set(cities).difference(configured_cities))
    if unknown:
        raise ValueError(f"Unknown configured cities: {unknown}")

    study = config["study"]
    lookback = int(study["lookback_hours"])
    city_metric_rows: list[dict[str, float | str]] = []
    prediction_frames: list[pd.DataFrame] = []
    ridge_metadata: list[dict[str, float | str]] = []
    sarima_diagnostics: list[dict[str, float | int | str | bool | None]] = []
    shap_lag_frames: list[pd.DataFrame] = []
    shap_group_frames: list[pd.DataFrame] = []
    shap_value_frames: list[pd.DataFrame] = []
    quality_rows: list[dict[str, float | int | str]] = []
    peak_rows: list[dict[str, float | int | str]] = []
    block_counts: dict[str, dict[str, int]] = {}

    for city in cities:
        frame = load_city_csv(data_dir / configured_cities[city], expected_city=city)
        quality_rows.append(_data_quality(city, frame))
        prepared = prepare_city(
            frame,
            lookback=lookback,
            train_fraction=float(study["train_fraction"]),
            validation_fraction=float(study["validation_fraction"]),
        )
        block_counts[city] = {
            f"{name}_rows": int(block_slice.stop - block_slice.start)
            for name, block_slice in prepared.slices.items()
        }
        block_counts[city].update(
            {f"{name}_windows": int(len(block.y)) for name, block in prepared.blocks.items()}
        )

        benchmark = fit_benchmarks(prepared, config, skip_mlp=skip_mlp)
        ridge_metadata.extend(benchmark.ridge_hyperparameters)
        test = prepared.blocks["test"]
        training_targets = prepared.frame.loc[
            prepared.slices["train"], list(prepared.target_names)
        ].astype(float).to_numpy()
        peak_rows.extend(
            peak_regime_rows(
                city,
                prepared.target_names,
                training_targets,
                test.y,
                benchmark.predictions,
            )
        )
        for model, prediction in benchmark.predictions.items():
            city_metric_rows.extend(
                metric_rows(city, model, prepared.target_names, test.y, prediction)
            )
            prediction_frames.append(
                _prediction_rows(
                    city,
                    model,
                    prepared.target_names,
                    test.timestamps,
                    test.y,
                    prediction,
                )
            )

        shap_result = exact_linear_shap(
            benchmark.ridge_all_model,
            benchmark.ridge_all_train_X,
            benchmark.ridge_all_test_X,
            prepared.feature_names,
            prepared.target_names,
            prepared.lookback,
        )
        lag_summary = shap_result.lag_summary.assign(
            city=city, max_reconstruction_error=shap_result.max_reconstruction_error
        )
        group_summary = shap_result.group_summary.assign(
            city=city, max_reconstruction_error=shap_result.max_reconstruction_error
        )
        group_values = shap_result.group_values.assign(city=city)
        group_values["timestamp"] = np.tile(
            pd.to_datetime(test.timestamps, utc=True).to_numpy(),
            len(prepared.feature_names) * len(prepared.target_names),
        )
        shap_lag_frames.append(lag_summary)
        shap_group_frames.append(group_summary)
        shap_value_frames.append(group_values)

        if not skip_sarima:
            sarima_prediction = np.empty_like(test.y, dtype=float)
            for target_index, target in enumerate(prepared.target_names):
                result = sarima_forecast(prepared, target, config["sarima"])
                sarima_prediction[:, target_index] = result.prediction
                sarima_diagnostics.append(result.diagnostics)
            city_metric_rows.extend(
                metric_rows(city, "SARIMA", prepared.target_names, test.y, sarima_prediction)
            )
            prediction_frames.append(
                _prediction_rows(
                    city,
                    "SARIMA",
                    prepared.target_names,
                    test.timestamps,
                    test.y,
                    sarima_prediction,
                )
            )

    city_metrics = pd.DataFrame(city_metric_rows).sort_values(
        ["target", "city", "RMSE", "model"], kind="stable"
    )
    macro_metrics = _macro_metrics(city_metrics)
    predictions = pd.concat(prediction_frames, ignore_index=True)
    shap_lag = pd.concat(shap_lag_frames, ignore_index=True)
    shap_group = pd.concat(shap_group_frames, ignore_index=True)
    shap_values = pd.concat(shap_value_frames, ignore_index=True)

    city_metrics.to_csv(output_dir / "city_model_metrics.csv", index=False)
    macro_metrics.to_csv(output_dir / "macro_model_metrics.csv", index=False)
    predictions.to_csv(output_dir / "predictions_long.csv", index=False)
    pd.DataFrame(ridge_metadata).to_csv(output_dir / "ridge_hyperparameters.csv", index=False)
    pd.DataFrame(sarima_diagnostics).to_csv(output_dir / "sarima_diagnostics.csv", index=False)
    shap_lag.to_csv(output_dir / "shap_lag_summary.csv", index=False)
    shap_group.to_csv(output_dir / "shap_grouped_summary.csv", index=False)
    shap_values.to_csv(output_dir / "shap_group_values.csv", index=False)
    pd.DataFrame(quality_rows).to_csv(output_dir / "data_quality_summary.csv", index=False)
    pd.DataFrame(peak_rows).to_csv(output_dir / "peak_regime_metrics.csv", index=False)

    if not skip_sarima:
        uncertainty = config["uncertainty"]
        bootstrap = pd.concat(
            [
                paired_city_bootstrap(
                    city_metrics,
                    reference_model=model,
                    comparison_model="Persistence",
                    replicates=int(uncertainty["bootstrap_replicates"]),
                    confidence_level=float(uncertainty["confidence_level"]),
                    seed=int(uncertainty["bootstrap_seed"]),
                    excluded_cities=("Rawalpindi",),
                )
                for model in ("Ridge-AR", "Ridge-All")
            ],
            ignore_index=True,
        )
        dm_results = dm_results_from_predictions(
            predictions, hac_lag=int(uncertainty["hac_lag"])
        )
        bootstrap.to_csv(output_dir / "paired_bootstrap_results.csv", index=False)
        dm_results.to_csv(output_dir / "dm_style_results.csv", index=False)

    _write_figures(output_dir, macro_metrics, shap_group, pd.DataFrame(quality_rows))
    def sha256_file(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    library_names = ("numpy", "pandas", "scipy", "scikit-learn", "statsmodels", "matplotlib", "PyYAML")
    library_versions = {}
    for library_name in library_names:
        try:
            library_versions[library_name] = importlib.metadata.version(library_name)
        except importlib.metadata.PackageNotFoundError:
            library_versions[library_name] = "not-installed"

    manifest = {
        "package_version": __version__,
        "python": sys.version,
        "platform": platform.platform(),
        "library_versions": library_versions,
        "data_dir": str(data_dir),
        "output_dir": str(output_dir),
        "cities": cities,
        "input_sha256": {
            city: sha256_file(data_dir / configured_cities[city]) for city in cities
        },
        "skip_sarima": bool(skip_sarima),
        "skip_mlp": bool(skip_mlp),
        "block_counts": block_counts,
        "config": config,
    }
    (output_dir / "run_manifest.json").write_text(
        json.dumps(manifest, indent=2, default=str), encoding="utf-8"
    )
    print(macro_metrics.to_string(index=False))
    print(f"\nWrote reproducibility outputs to {output_dir.resolve()}")
