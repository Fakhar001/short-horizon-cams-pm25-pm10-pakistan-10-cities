"""Data validation, leakage-controlled scaling, and within-block windows."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler


TARGETS = ("pm2_5", "pm10")
METEOROLOGY = (
    "temperature_2m",
    "relative_humidity_2m",
    "wind_speed_10m",
    "wind_dir_sin",
    "wind_dir_cos",
    "surface_pressure",
    "precipitation",
)
ALL_FEATURES = TARGETS + METEOROLOGY


@dataclass(frozen=True)
class WindowBlock:
    X: np.ndarray
    y: np.ndarray
    timestamps: np.ndarray
    raw_indices: np.ndarray


@dataclass(frozen=True)
class PreparedCity:
    city: str
    frame: pd.DataFrame
    scaler: StandardScaler
    blocks: dict[str, WindowBlock]
    slices: dict[str, slice]
    feature_names: tuple[str, ...]
    target_names: tuple[str, ...]
    lookback: int


def encode_wind_direction(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    radians = np.deg2rad(result["wind_direction_10m"].astype(float).to_numpy())
    result["wind_dir_sin"] = np.sin(radians)
    result["wind_dir_cos"] = np.cos(radians)
    return result


def chronological_slices(
    n_rows: int, train_fraction: float = 0.70, validation_fraction: float = 0.10
) -> dict[str, slice]:
    n_train = int(n_rows * train_fraction)
    n_validation = int(n_rows * validation_fraction)
    if min(n_train, n_validation, n_rows - n_train - n_validation) <= 0:
        raise ValueError("Every chronological block must contain observations.")
    return {
        "train": slice(0, n_train),
        "validation": slice(n_train, n_train + n_validation),
        "test": slice(n_train + n_validation, n_rows),
    }


def _window_block(
    features: np.ndarray,
    targets: np.ndarray,
    timestamps: np.ndarray,
    block_slice: slice,
    lookback: int,
) -> WindowBlock:
    start = int(block_slice.start or 0)
    stop = int(block_slice.stop or len(features))
    if stop - start <= lookback:
        raise ValueError("A chronological block is too short for the requested lookback.")
    origins = np.arange(start + lookback, stop, dtype=int)
    X = np.stack([features[index - lookback : index] for index in origins])
    return WindowBlock(
        X=X,
        y=targets[origins],
        timestamps=timestamps[origins],
        raw_indices=origins,
    )


def load_city_csv(path: Path, expected_city: str | None = None) -> pd.DataFrame:
    frame = pd.read_csv(path, parse_dates=["timestamp"])
    required = {
        "city",
        "timestamp",
        "pm2_5",
        "pm10",
        "temperature_2m",
        "relative_humidity_2m",
        "wind_speed_10m",
        "wind_direction_10m",
        "surface_pressure",
        "precipitation",
    }
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"{path.name} is missing columns: {sorted(missing)}")
    frame = frame.sort_values("timestamp", kind="stable").reset_index(drop=True)
    if frame["timestamp"].duplicated().any():
        raise ValueError(f"{path.name} contains duplicate timestamps.")
    if frame[list(required - {"city", "timestamp"})].isna().any().any():
        raise ValueError(f"{path.name} contains missing modelling values.")
    if expected_city and frame["city"].nunique() == 1 and frame["city"].iloc[0] != expected_city:
        raise ValueError(f"Expected city {expected_city!r}, found {frame['city'].iloc[0]!r}.")
    return frame


def prepare_city(
    frame: pd.DataFrame,
    lookback: int = 24,
    train_fraction: float = 0.70,
    validation_fraction: float = 0.10,
) -> PreparedCity:
    encoded = encode_wind_direction(frame.sort_values("timestamp", kind="stable").reset_index(drop=True))
    slices = chronological_slices(len(encoded), train_fraction, validation_fraction)
    raw_features = encoded.loc[:, ALL_FEATURES].astype(float).to_numpy()
    raw_targets = encoded.loc[:, TARGETS].astype(float).to_numpy()
    train_slice = slices["train"]
    scaler = StandardScaler().fit(raw_features[train_slice])
    scaled_features = scaler.transform(raw_features)
    timestamps = encoded["timestamp"].to_numpy()
    blocks = {
        name: _window_block(scaled_features, raw_targets, timestamps, block_slice, lookback)
        for name, block_slice in slices.items()
    }
    city = str(encoded["city"].iloc[0])
    return PreparedCity(
        city=city,
        frame=encoded,
        scaler=scaler,
        blocks=blocks,
        slices=slices,
        feature_names=ALL_FEATURES,
        target_names=TARGETS,
        lookback=lookback,
    )


def flattened_feature_names(feature_names: tuple[str, ...], lookback: int) -> list[str]:
    names: list[str] = []
    for lag_position in range(lookback):
        lag = lookback - lag_position
        names.extend(f"{feature}_lag_{lag}" for feature in feature_names)
    return names

