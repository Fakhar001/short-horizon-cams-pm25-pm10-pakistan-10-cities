"""Configuration loading and validation."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


def load_config(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as stream:
        config = yaml.safe_load(stream)

    required = {"study", "features", "ridge", "sarima", "uncertainty", "cities"}
    missing = required.difference(config)
    if missing:
        raise ValueError(f"Missing configuration sections: {sorted(missing)}")

    fractions = (
        float(config["study"]["train_fraction"]),
        float(config["study"]["validation_fraction"]),
    )
    if fractions[0] <= 0 or fractions[1] <= 0 or sum(fractions) >= 1:
        raise ValueError("Train and validation fractions must be positive and sum to less than one.")
    return config

