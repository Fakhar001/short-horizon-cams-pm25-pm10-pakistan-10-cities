"""Exact additive attributions for multi-output linear Ridge models."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge

from .data import flattened_feature_names


@dataclass(frozen=True)
class LinearShapResult:
    lag_summary: pd.DataFrame
    group_summary: pd.DataFrame
    group_values: pd.DataFrame
    max_reconstruction_error: float


def exact_linear_shap(
    model: Ridge,
    train_X: np.ndarray,
    test_X: np.ndarray,
    feature_names: tuple[str, ...],
    target_names: tuple[str, ...],
    lookback: int,
) -> LinearShapResult:
    train_X = np.asarray(train_X, dtype=float)
    test_X = np.asarray(test_X, dtype=float)
    coefficients = np.asarray(model.coef_, dtype=float)
    if coefficients.ndim == 1:
        coefficients = coefficients[None, :]
    if coefficients.shape[1] != test_X.shape[1]:
        raise ValueError("Model coefficient and feature dimensions do not match.")

    background = np.mean(train_X, axis=0)
    phi = (test_X - background)[..., None] * coefficients.T[None, ...]
    base = np.asarray(model.intercept_, dtype=float) + background @ coefficients.T
    reconstructed = base[None, :] + phi.sum(axis=1)
    prediction = np.asarray(model.predict(test_X), dtype=float)
    max_error = float(np.max(np.abs(reconstructed - prediction)))
    if max_error > 1e-8:
        raise AssertionError(f"Linear SHAP reconstruction error is {max_error:.3e}")

    flat_names = flattened_feature_names(feature_names, lookback)
    lag_rows: list[dict[str, float | int | str]] = []
    for feature_index, flat_name in enumerate(flat_names):
        feature_group = flat_name.rsplit("_lag_", 1)[0]
        lag = int(flat_name.rsplit("_lag_", 1)[1])
        for target_index, target in enumerate(target_names):
            values = phi[:, feature_index, target_index]
            lag_rows.append(
                {
                    "target": target,
                    "feature": feature_group,
                    "lag": lag,
                    "mean_abs_shap": float(np.mean(np.abs(values))),
                    "mean_signed_shap": float(np.mean(values)),
                }
            )
    lag_summary = pd.DataFrame(lag_rows)

    group_rows: list[dict[str, float | str]] = []
    value_frames: list[pd.DataFrame] = []
    for feature_position, feature in enumerate(feature_names):
        indices = np.arange(feature_position, test_X.shape[1], len(feature_names))
        for target_index, target in enumerate(target_names):
            signed_group = phi[:, indices, target_index].sum(axis=1)
            mean_abs = float(np.mean(np.abs(signed_group)))
            group_rows.append(
                {
                    "target": target,
                    "feature": feature,
                    "mean_abs_group_shap": mean_abs,
                    "mean_signed_group_shap": float(np.mean(signed_group)),
                    "sum_lag_mean_abs_shap": float(
                        lag_summary[
                            (lag_summary["target"] == target)
                            & (lag_summary["feature"] == feature)
                        ]["mean_abs_shap"].sum()
                    ),
                }
            )
            value_frames.append(
                pd.DataFrame(
                    {
                        "test_origin": np.arange(len(test_X)),
                        "target": target,
                        "feature": feature,
                        "signed_group_shap": signed_group,
                    }
                )
            )
    group_summary = pd.DataFrame(group_rows)
    group_summary["share"] = group_summary.groupby("target")["mean_abs_group_shap"].transform(
        lambda series: series / series.sum() if series.sum() else np.nan
    )
    group_values = pd.concat(value_frames, ignore_index=True)
    return LinearShapResult(lag_summary, group_summary, group_values, max_error)

