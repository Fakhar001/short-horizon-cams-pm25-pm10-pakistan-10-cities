"""Leakage-controlled benchmark models used in the manuscript."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error
from sklearn.neural_network import MLPRegressor

from .data import PreparedCity


@dataclass
class BenchmarkResult:
    predictions: dict[str, np.ndarray]
    ridge_hyperparameters: list[dict[str, float | str]]
    ridge_all_model: Ridge
    ridge_all_train_X: np.ndarray
    ridge_all_test_X: np.ndarray


def _flatten(array: np.ndarray, feature_count: int | None = None) -> np.ndarray:
    selected = array if feature_count is None else array[:, :, :feature_count]
    return selected.reshape(len(selected), -1)


def _validation_rmse(y_true: np.ndarray, prediction: np.ndarray) -> float:
    raw = mean_squared_error(y_true, prediction, multioutput="raw_values")
    return float(np.mean(np.sqrt(np.asarray(raw))))


def _tuned_ridge(
    train_X: np.ndarray,
    train_y: np.ndarray,
    validation_X: np.ndarray,
    validation_y: np.ndarray,
    alpha_grid: list[float],
) -> tuple[Ridge, float, float]:
    candidates: list[tuple[float, float, Ridge]] = []
    for alpha in alpha_grid:
        model = Ridge(alpha=float(alpha)).fit(train_X, train_y)
        score = _validation_rmse(validation_y, model.predict(validation_X))
        candidates.append((score, float(alpha), model))
    score, alpha, model = min(candidates, key=lambda item: (item[0], item[1]))
    return model, alpha, score


def fit_benchmarks(
    prepared: PreparedCity,
    config: dict[str, Any],
    skip_mlp: bool = False,
) -> BenchmarkResult:
    train = prepared.blocks["train"]
    validation = prepared.blocks["validation"]
    test = prepared.blocks["test"]
    raw_targets = prepared.frame.loc[:, prepared.target_names].astype(float).to_numpy()

    predictions: dict[str, np.ndarray] = {
        "Persistence": raw_targets[test.raw_indices - 1],
        "Seasonal naive": raw_targets[test.raw_indices - prepared.lookback],
    }

    ridge_metadata: list[dict[str, float | str]] = []
    alpha_grid = [float(value) for value in config["ridge"]["alpha_grid"]]

    train_pm = _flatten(train.X, feature_count=2)
    validation_pm = _flatten(validation.X, feature_count=2)
    test_pm = _flatten(test.X, feature_count=2)
    ridge_ar, alpha_ar, score_ar = _tuned_ridge(
        train_pm, train.y, validation_pm, validation.y, alpha_grid
    )
    predictions["Ridge-AR"] = ridge_ar.predict(test_pm)
    ridge_metadata.append(
        {
            "city": prepared.city,
            "model": "Ridge-AR",
            "selected_alpha": alpha_ar,
            "validation_macro_RMSE": score_ar,
        }
    )

    train_all = _flatten(train.X)
    validation_all = _flatten(validation.X)
    test_all = _flatten(test.X)
    ridge_all, alpha_all, score_all = _tuned_ridge(
        train_all, train.y, validation_all, validation.y, alpha_grid
    )
    predictions["Ridge-All"] = ridge_all.predict(test_all)
    ridge_metadata.append(
        {
            "city": prepared.city,
            "model": "Ridge-All",
            "selected_alpha": alpha_all,
            "validation_macro_RMSE": score_all,
        }
    )

    rf_config = config["random_forest"]
    random_forest = RandomForestRegressor(
        n_estimators=int(rf_config["n_estimators"]),
        min_samples_leaf=int(rf_config["min_samples_leaf"]),
        max_features=float(rf_config["max_features"]),
        random_state=int(rf_config["random_state"]),
        n_jobs=1,
    ).fit(train_all, train.y)
    predictions["Random Forest"] = random_forest.predict(test_all)

    gb_config = config["gradient_boosting"]
    gradient_models = []
    for target_index in range(train.y.shape[1]):
        model = HistGradientBoostingRegressor(
            max_iter=int(gb_config["max_iter"]),
            learning_rate=float(gb_config["learning_rate"]),
            max_leaf_nodes=int(gb_config["max_leaf_nodes"]),
            l2_regularization=float(gb_config["l2_regularization"]),
            random_state=int(gb_config["random_state"]),
        ).fit(train_all, train.y[:, target_index])
        gradient_models.append(model)
    predictions["Gradient Boosting"] = np.column_stack(
        [model.predict(test_all) for model in gradient_models]
    )

    if not skip_mlp:
        mlp_config = config["mlp"]
        mlp = MLPRegressor(
            hidden_layer_sizes=tuple(int(value) for value in mlp_config["hidden_layer_sizes"]),
            early_stopping=bool(mlp_config["early_stopping"]),
            max_iter=int(mlp_config["max_iter"]),
            random_state=int(mlp_config["random_state"]),
        ).fit(train_all, train.y)
        predictions["MLP lag-window"] = mlp.predict(test_all)

    return BenchmarkResult(
        predictions=predictions,
        ridge_hyperparameters=ridge_metadata,
        ridge_all_model=ridge_all,
        ridge_all_train_X=train_all,
        ridge_all_test_X=test_all,
    )

