"""Forecast evaluation metrics."""

from __future__ import annotations

import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def metric_vector(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, np.ndarray]:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    if y_true.shape != y_pred.shape:
        raise ValueError(f"Shape mismatch: actual {y_true.shape}, prediction {y_pred.shape}")
    return {
        "MAE": np.asarray(mean_absolute_error(y_true, y_pred, multioutput="raw_values")),
        "RMSE": np.sqrt(np.asarray(mean_squared_error(y_true, y_pred, multioutput="raw_values"))),
        "R2": np.atleast_1d(r2_score(y_true, y_pred, multioutput="raw_values")),
        "Bias": np.mean(y_pred - y_true, axis=0),
    }


def metric_rows(city: str, model: str, targets: tuple[str, ...], y_true: np.ndarray, y_pred: np.ndarray) -> list[dict[str, float | str]]:
    values = metric_vector(y_true, y_pred)
    rows: list[dict[str, float | str]] = []
    for index, target in enumerate(targets):
        rows.append(
            {
                "city": city,
                "model": model,
                "target": target,
                **{name: float(vector[index]) for name, vector in values.items()},
            }
        )
    return rows


def peak_regime_rows(
    city: str,
    targets: tuple[str, ...],
    training_targets: np.ndarray,
    test_targets: np.ndarray,
    predictions: dict[str, np.ndarray],
    reference_models: tuple[str, ...] = ("Ridge-AR", "Persistence"),
) -> list[dict[str, float | int | str]]:
    """Score Ridge and persistence errors above training-only P95 thresholds."""
    training_targets = np.asarray(training_targets, dtype=float)
    test_targets = np.asarray(test_targets, dtype=float)
    rows: list[dict[str, float | int | str]] = []
    for target_index, target in enumerate(targets):
        threshold = float(np.quantile(training_targets[:, target_index], 0.95))
        event_mask = test_targets[:, target_index] >= threshold
        event_count = int(event_mask.sum())
        for model in reference_models:
            if model not in predictions:
                continue
            predicted = np.asarray(predictions[model], dtype=float)
            actual_event = test_targets[event_mask, target_index]
            predicted_event = predicted[event_mask, target_index]
            rows.append(
                {
                    "city": city,
                    "target": target,
                    "threshold_training_p95": threshold,
                    "n_test_events": event_count,
                    "model": model,
                    "MAE": float(np.mean(np.abs(predicted_event - actual_event))) if event_count else float("nan"),
                    "RMSE": float(np.sqrt(np.mean((predicted_event - actual_event) ** 2))) if event_count else float("nan"),
                    "Bias": float(np.mean(predicted_event - actual_event)) if event_count else float("nan"),
                }
            )
    return rows

