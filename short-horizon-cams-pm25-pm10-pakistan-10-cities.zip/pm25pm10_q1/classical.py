"""Seasonal ARIMA benchmark with fixed-origin and rolling one-step protocols."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
from scipy.optimize import least_squares

from .data import PreparedCity


@dataclass(frozen=True)
class SarimaResult:
    prediction: np.ndarray
    diagnostics: dict[str, float | int | str | bool | None]


class ConditionalLeastSquaresSarima:
    """Dependency-light SARIMA(1,0,0)(1,0,0)[s] fallback.

    The conditional mean is
    c + phi*y[t-1] + Phi*y[t-s] - phi*Phi*y[t-s-1].
    This fallback is useful for tests and constrained environments. The
    manuscript analysis should use the statsmodels state-space backend.
    """

    def __init__(self, seasonal_period: int = 24):
        self.seasonal_period = int(seasonal_period)
        self.params_: np.ndarray | None = None

    def fit(self, values: np.ndarray) -> "ConditionalLeastSquaresSarima":
        y = np.asarray(values, dtype=float)
        start = self.seasonal_period + 1
        if len(y) <= start + 3:
            raise ValueError("Series is too short for seasonal conditional least squares.")

        def residuals(parameters: np.ndarray) -> np.ndarray:
            intercept, phi, seasonal_phi = parameters
            fitted = (
                intercept
                + phi * y[start - 1 : -1]
                + seasonal_phi * y[start - self.seasonal_period : -self.seasonal_period]
                - phi
                * seasonal_phi
                * y[start - self.seasonal_period - 1 : -self.seasonal_period - 1]
            )
            return y[start:] - fitted

        initial = np.array([float(np.mean(y)) * 0.01, 0.5, 0.2])
        fit = least_squares(
            residuals,
            initial,
            bounds=([-np.inf, -0.999, -0.999], [np.inf, 0.999, 0.999]),
        )
        self.params_ = fit.x
        return self

    def forecast(self, history: np.ndarray, steps: int) -> np.ndarray:
        if self.params_ is None:
            raise RuntimeError("Fit the model before forecasting.")
        intercept, phi, seasonal_phi = self.params_
        values = list(np.asarray(history, dtype=float))
        forecasts: list[float] = []
        for _ in range(int(steps)):
            estimate = (
                intercept
                + phi * values[-1]
                + seasonal_phi * values[-self.seasonal_period]
                - phi * seasonal_phi * values[-self.seasonal_period - 1]
            )
            values.append(float(estimate))
            forecasts.append(float(estimate))
        return np.asarray(forecasts)


def _fit_statsmodels(values: np.ndarray, sarima_config: dict[str, Any]):
    try:
        from statsmodels.tsa.statespace.sarimax import SARIMAX
    except ImportError as exc:
        raise ImportError(
            "statsmodels is required for the configured SARIMA backend. "
            "Install requirements.txt or use --sarima-backend css for a smoke run."
        ) from exc

    model = SARIMAX(
        np.asarray(values, dtype=float),
        order=tuple(int(value) for value in sarima_config["order"]),
        seasonal_order=tuple(int(value) for value in sarima_config["seasonal_order"]),
        trend=str(sarima_config.get("trend", "c")),
        enforce_stationarity=bool(sarima_config.get("enforce_stationarity", False)),
        enforce_invertibility=bool(sarima_config.get("enforce_invertibility", False)),
    )
    return model.fit(disp=False, maxiter=200)


def _fixed_origin_forecast(
    train: np.ndarray,
    validation: np.ndarray,
    test: np.ndarray,
    lookback: int,
    config: dict[str, Any],
) -> tuple[np.ndarray, dict[str, float | int | str | bool | None]]:
    backend = str(config.get("backend", "statsmodels"))
    total_steps = len(validation) + len(test)
    if backend == "statsmodels":
        fitted = _fit_statsmodels(train, config)
        all_forecasts = np.asarray(fitted.forecast(total_steps), dtype=float)
        diagnostics = {
            "converged": bool(fitted.mle_retvals.get("converged", False)),
            "aic": float(fitted.aic),
            "bic": float(fitted.bic),
        }
    elif backend == "css":
        seasonal_period = int(config["seasonal_order"][3])
        fitted = ConditionalLeastSquaresSarima(seasonal_period).fit(train)
        all_forecasts = fitted.forecast(train, total_steps)
        diagnostics = {"converged": True, "aic": None, "bic": None}
    else:
        raise ValueError(f"Unsupported SARIMA backend: {backend}")

    test_forecast = all_forecasts[len(validation) :]
    return test_forecast[lookback:], diagnostics


def _rolling_one_step_forecast(
    train: np.ndarray,
    validation: np.ndarray,
    test: np.ndarray,
    lookback: int,
    config: dict[str, Any],
) -> tuple[np.ndarray, dict[str, float | int | str | bool | None]]:
    backend = str(config.get("backend", "statsmodels"))
    # Estimate SARIMA parameters on the training block only. Validation and
    # the first lookback hours of the test block are state warm-up observations
    # available before the first scored one-step forecast; they must not be
    # used to re-estimate model parameters.
    warmup = np.concatenate([validation, test[:lookback]])
    future_actuals = np.asarray(test[lookback:], dtype=float)
    predictions: list[float] = []

    if backend == "statsmodels":
        fitted = _fit_statsmodels(train, config)
        initial_aic = float(fitted.aic)
        initial_bic = float(fitted.bic)
        converged = bool(fitted.mle_retvals.get("converged", False))
        if len(warmup):
            fitted = fitted.append(warmup, refit=False)
        if len(future_actuals):
            # Appending the scored observations as one batch runs the same
            # sequential Kalman filter: each prediction is made from the
            # state before that observation, and each actual then updates the
            # state for the next origin. Parameters remain fixed at their
            # training-block estimates. The filtered one-step forecasts are
            # substantially faster than repeatedly rebuilding Results objects
            # one hour at a time.
            updated = fitted.append(future_actuals, refit=False)
            forecasts = np.asarray(updated.filter_results.forecasts, dtype=float)
            predictions = forecasts[0, -len(future_actuals) :].tolist()
        diagnostics = {"converged": converged, "aic": initial_aic, "bic": initial_bic}
    elif backend == "css":
        seasonal_period = int(config["seasonal_order"][3])
        fitted = ConditionalLeastSquaresSarima(seasonal_period).fit(train)
        history = list(np.concatenate([train, warmup]))
        for actual in future_actuals:
            predictions.append(float(fitted.forecast(np.asarray(history), 1)[0]))
            history.append(float(actual))
        diagnostics = {"converged": True, "aic": None, "bic": None}
    else:
        raise ValueError(f"Unsupported SARIMA backend: {backend}")
    return np.asarray(predictions), diagnostics


def sarima_forecast(
    prepared: PreparedCity,
    target: str,
    sarima_config: dict[str, Any],
) -> SarimaResult:
    if target not in prepared.target_names:
        raise ValueError(f"Unknown target: {target}")
    raw = prepared.frame[target].astype(float).to_numpy()
    train = raw[prepared.slices["train"]]
    validation = raw[prepared.slices["validation"]]
    test = raw[prepared.slices["test"]]
    protocol = str(sarima_config.get("protocol", "fixed_origin_training_only"))

    if protocol == "fixed_origin_training_only":
        prediction, diagnostics = _fixed_origin_forecast(
            train, validation, test, prepared.lookback, sarima_config
        )
    elif protocol == "rolling_one_step":
        prediction, diagnostics = _rolling_one_step_forecast(
            train, validation, test, prepared.lookback, sarima_config
        )
    else:
        raise ValueError(f"Unsupported SARIMA protocol: {protocol}")

    expected = len(prepared.blocks["test"].y)
    if len(prediction) != expected:
        raise AssertionError(f"SARIMA produced {len(prediction)} predictions; expected {expected}.")
    diagnostics.update(
        {
            "city": prepared.city,
            "target": target,
            "protocol": protocol,
            "backend": str(sarima_config.get("backend", "statsmodels")),
            "n_test_origins": expected,
        }
    )
    return SarimaResult(prediction=np.asarray(prediction), diagnostics=diagnostics)

